import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.IOException;

public class About extends JFrame{

    private boolean deviceState = false;
    ;
    JLabel background = new JLabel();
    JButton onOffButton = new JButton();
    JButton plusButton = new JButton();
    JButton minusButton = new JButton();
    JButton selectButton = new JButton();
    JButton menuButton = new JButton();

    JLabel aboutImage = new JLabel();
    //private JButton about;
    private JFrame frame;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new About().frame();
            } catch (Exception ex) {
                System.out.println(ex);
            }
        });

    }

    public void frame() throws IOException {
        frame = new JFrame("About");
        frame.setVisible(true);
        frame.setSize(370, 635);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        background.setIcon(new ImageIcon(ImageIO.read(this.getClass().getResource("images/xtrek_on_template.png"))));
        background.setBounds(0, 0, 360, 600);
        frame.add(background);

        //Creates the onOffButton
        onOffButton.setIcon(new ImageIcon(this.getClass().getResource("/images/onoff.png")));
        onOffButton.setBounds(234, 106, 45, 45);
        onOffButton.addActionListener(e -> {
            try {
                onOffPressed();

            } catch (Exception ex)
            {
                System.out.println(ex);}
        });
        frame.add(onOffButton);

        //Creates the plusButton
        plusButton.setBounds(10, 60, 30, 55);
        //plusButton.setBorder(null);
        plusButton.addActionListener(e -> plusButtonPressed());
        plusButton.setOpaque(false);
        plusButton.setContentAreaFilled(false);
        frame.add(plusButton);

        //Creates the minusButton
        minusButton.setBounds(10, 115, 30, 55);
        //minusButton.setBorder(null);
        minusButton.addActionListener(e -> minusButtonPressed());
        minusButton.setOpaque(false);
        minusButton.setContentAreaFilled(false);
        frame.add(minusButton);

        //Creates the selectButton
        selectButton.setBounds(10, 190, 30, 65);
        //selectButton.setBorder(null);
        selectButton.addActionListener(e -> selectButtonPressed());
        selectButton.setOpaque(false);
        selectButton.setContentAreaFilled(false);
        frame.add(selectButton);

        //Creates the menuButton
        menuButton.setBounds(320, 70, 30, 65);
        menuButton.addActionListener(e -> menuButtonPressed());
        menuButton.setOpaque(false);
        menuButton.setContentAreaFilled(false);
        frame.add(menuButton);

        frame.setLocationRelativeTo(null); //This is for centering the frame to your screen.

    }


    public void selectButtonPressed() {

        plusButton.setEnabled(false);
        minusButton.setEnabled(false);
        try {
            aboutImage.setIcon(new ImageIcon(ImageIO.read(this.getClass().getResource("images/player.png"))));
        } catch (IOException e) {
            e.printStackTrace();
        }
        aboutImage.setBounds(90,185,220,300);
        frame.add(aboutImage);
    }

    public void onOffPressed() {
        aboutImage.setIcon(null);
        plusButton.setEnabled(true);
        minusButton.setEnabled(true);


    }

    public void plusButtonPressed() {

    }

    public void minusButtonPressed() {

    }

    public void menuButtonPressed() {
        aboutImage.setIcon(null);
        plusButton.setEnabled(true);
        minusButton.setEnabled(true);
    }
}

