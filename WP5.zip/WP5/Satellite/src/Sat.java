import net.codejava.swing.CustomOutputStream;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintStream;

public class Sat extends JFrame {

    private JFrame frame;
    private JPanel panel;
    private JTextArea textArea;

    private JButton satellite;
    private JButton about;

    public Sat() throws IOException {
        frame = new JFrame("Work Package 5");
        frame.setVisible(true);
        frame.setSize(300, 380);

        about = new JButton("About");
        //add(about);

        satellite = new JButton("Satellite");
        
        event1 sat = new event1();
        satellite.addActionListener(sat);

        panel = new JPanel();
        frame.add(panel);
        panel.add(about);
        panel.add(satellite);

        frame.setLocationRelativeTo(null); //This is for centering the frame to your screen.
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE); //This for closing your application after you closing the window.
    }

    public class event1 implements ActionListener {
        public void actionPerformed(ActionEvent sat) {
            panel.setVisible(false);
            textArea = new JTextArea(50, 10);
            frame.add(textArea);
            //frame.add(new JScrollPane(textArea));
            textArea.setEditable(false);
            PrintStream printStream = new PrintStream(new CustomOutputStream(textArea));
            System.setOut(printStream);
            System.setErr(printStream);

            printLog();
        }
    }

    private void printLog() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    OSXUblox7.reader1("/dev/cu.usbmodem1411");
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        thread.start();
    }

public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    new Sat();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}